﻿namespace LoginApi.DTO
{
    public class UserDto
    {
        
        public string Name { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public int RoleID { get; set; }

        public IFormFile UserImage { get; set; }

        //public byte? Status { get; set; }
    }
}

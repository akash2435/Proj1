
using LoginApi.Entities;
using LoginApi.Interface;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.




builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options => options.AddPolicy("prodpolicy", (polbuilder) =>
{
    polbuilder.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin();
}));

builder.Services.AddScoped<IUserRepository<User>, UserRepository>();
builder.Services.AddDbContext<UserDbmanagContext>((Options) => Options.UseSqlServer(builder.Configuration.GetConnectionString("ConString")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseStaticFiles();
app.UseCors("prodpolicy");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

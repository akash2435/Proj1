﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using LoginApi.Entities;
using LoginApi.Interface;
using Microsoft.EntityFrameworkCore;

namespace LoginApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IWebHostEnvironment webHostEnvironment;
        private readonly UserDbmanagContext userDbmanagContext;

        IUserRepository<User> userRepository;
        public UserController(IUserRepository<User> userRepository, IWebHostEnvironment webHostEnvironment, UserDbmanagContext userDbmanagContext)
        {
            this.userRepository = userRepository;
            this.webHostEnvironment = webHostEnvironment;
            this.userDbmanagContext = userDbmanagContext;
        }



        [HttpPost("SignUp")]
        public async Task<IActionResult> UserSignUp([FromForm] DTO.UserDto dto)
        {
            ApiResponseType response = new ApiResponseType();
            try
            {

                using (MemoryStream stream = new MemoryStream())
                {
                    dto.UserImage.CopyTo(stream);
                    this.userDbmanagContext.Users.Add(new Entities.User()
                    {
                        Name = dto.Name,
                        Email = dto.Email,
                        Password = dto.Password,
                        RoleId = dto.RoleID,
                        UserImage = stream.ToArray()
                    });
                    await this.userDbmanagContext.SaveChangesAsync();
                }

            }
            catch (Exception ex)
            {
            }

            return Ok(response);
        }



        [HttpGet("AllUsers")]
        public IActionResult GetAll()
        {
            var users = userRepository.GetAll();

            var dtousers = users.Select(p => new
            {
                Id = p.Id,
                Name = p.Name,
                Email = p.Email,
                Password = p.Password,
                RoleID = p.RoleId

            });
            return Ok(dtousers);
        }

        [HttpGet("GetByName")]
        public IActionResult GetByName(string name)
        {
            var data = userRepository.SearchByName(name);
            var item = new
            {
                id = data.Id,
                Name = data.Name,
                RoleId = data.RoleId,
                Email = data.Email,
                Password = data.Password

            };
            return Ok(item);
        }




        //PUT api/<UserController>/5
        [HttpGet("GetById")]
        public IActionResult Get(int id)
        {
            var data = userRepository.GetById(id);
            var item = new
            {
                id = data.Id,
                name = data.Name,
                roleID = data.RoleId,
                email = data.Email,
                password = data.Password

            };
            return Ok(item);
        }






        [HttpPut("EditUser")]
        public IActionResult Put([FromForm] int Id, [FromForm] string Name, [FromForm] string Password, [FromForm] string Email, [FromForm] int RoleID)
        {
            var x = userRepository.GetById(Id);

            if (x == null)
            {
                return NotFound();
            }

            x.Name = Name;
            x.Email = Email;
            x.Password = Password;
            x.RoleId = RoleID;

            userRepository.Update(x);
            return Ok(new { status = 200 });
        }







        /*
                [HttpPut("EditUser")]
                public IActionResult Put([FromForm] int Id, string Name, string Password, string Email, int RoleID)
                {
                    var x = userRepository.GetById(Id);
                    ////var formData = HttpContext.Request.Form;

                    if (x == null)
                    {
                        return NotFound();
                    }
                    x.Id = Id;
                    x.Name = Name;
                    x.Email =Email;
                    x.Password = Password;
                    x.RoleID = RoleID;
                    userRepository.Update(x);
                    return Ok(x);

                }*/


        //    [HttpPut("EditUser/{id}")]
        //    public IActionResult UpdateUser(int id, [FromBody] DTO.UserDto userDto)
        //    {
        //        var existingUser = userRepository.GetById(id);

        //        if (existingUser == null)
        //        {
        //            return NotFound(); // Assuming NotFound is appropriate for a non-existent user
        //        }

        //        // Update only the properties you want to change
        //        existingUser.Name = userDto.Name;
        //        existingUser.Email = userDto.Email;
        //        existingUser.Password = userDto.Password;
        //        existingUser.RoleId = userDto.RoleID;

        //        // Do not update the image property

        //        userRepository.Update(existingUser);

        //        return Ok(existingUser);
        //    }
        //}


        //DELETE api/<UserController>/5
        [HttpDelete("DeleteUser")]
        public void Delete(int id)
        {
            var y = userRepository.GetById(id);
            userRepository.Delete(y);
        }
    }
}

﻿namespace LoginApi.Interface
{
    public interface IUserRepository<T>
    {
        T Add(T user);

        IEnumerable<T> GetAll();
        T GetById(int id);

        T SearchByName(string username);

        T Update(T user);

        void Delete(T id);
    }
}

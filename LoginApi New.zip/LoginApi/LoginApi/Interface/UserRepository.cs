﻿using LoginApi.Entities;
using Microsoft.EntityFrameworkCore.Scaffolding.Metadata;

namespace LoginApi.Interface
{
    public class UserRepository : IUserRepository<User>
    {
        UserDbmanagContext context;
        public UserRepository(UserDbmanagContext context)
        {
            this.context = context;
        }
        public User Add(User user)
        {
            context.Users.Add(user);
            context.SaveChanges();
            return user;
        }

        public void Delete(User user)
        {
            var item = GetById(user.Id);
            context.Users.Remove(item);
            context.SaveChanges();

        }

        public IEnumerable<User> GetAll()
        {
            return context.Users.ToList();
        }

        public User GetById(int id)
        {
            var data = context.Users.FirstOrDefault(x => x.Id == id);
           
            return data;
        }

        public User SearchByName(string username)
        {

            var data = context.Users.FirstOrDefault(x => x.Name == username.ToLower());
            return data;

        }

        public User Update(User user)
        {
            var data = GetById(user.Id);
            if (data != null)
            {
                data.Name = user.Name;
                data.Email = user.Email;
                data.RoleId = user.RoleId;
                data.Password = user.Password;
                context.SaveChanges();
            }
            return data;
        }


    }
}

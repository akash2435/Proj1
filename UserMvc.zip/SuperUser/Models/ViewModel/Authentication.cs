﻿namespace SuperUser.Models.ViewModel
{
    public class Authentication
    {
        public string OTP { get; set; }    
    }
}

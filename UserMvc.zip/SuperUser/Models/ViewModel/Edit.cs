﻿namespace SuperUser.Models.ViewModel
{
    public class Edit
    {
        public int Roleid { get; set; }

        public string Name { get; set; }

        public string email { get; set; }

    }
}

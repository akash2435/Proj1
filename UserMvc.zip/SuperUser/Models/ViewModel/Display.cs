﻿namespace SuperUser.Models.ViewModel
{
    public class Display
    {

    }
}

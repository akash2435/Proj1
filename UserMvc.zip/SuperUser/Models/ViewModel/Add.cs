﻿namespace SuperUser.Models.ViewModel
{
    public class Add
    {
        public int id { get; set; }

        public string name { get; set; }

        public string email { get; set; }

        public string password { get; set; }

        public int Roleid { get; set; }

        public string status { get; set; }

        public string PhotoPath { get; set; }
    }
}

﻿namespace SuperUser.Models.ViewModel
{
    public class Login
    {
        public string Username {  get; set; }

        public string password { get; set; }
    }
}

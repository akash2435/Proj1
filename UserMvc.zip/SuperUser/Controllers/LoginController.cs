﻿using Microsoft.AspNetCore.Mvc;

namespace SuperUser.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Front()
        {
            return View();
        }
        public IActionResult Add()
        {
            return View();
        }

        public IActionResult Edit()
        {
            return View();
        }

        public IActionResult Display()
        {
            return View();
        }

        public IActionResult Delete()
        {
            return View();
        }

        public IActionResult index()
        {
            return View();
        }

        public IActionResult Authentication()
        {
            return View();
        }
    }
}
